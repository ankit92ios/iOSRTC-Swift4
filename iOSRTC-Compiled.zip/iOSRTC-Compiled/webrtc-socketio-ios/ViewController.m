//
//  ViewController.m
//  webrtc-socketio-ios
//
//  Created by Disakul CG2 on 2/9/2560 BE.
//  Copyright © 2560 Digix Technology. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
