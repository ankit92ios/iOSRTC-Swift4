# iOSRTC
Convert code from AndroidRTC for iOS (Objective-C) platform. You must use iOSRTC with ProjectRTC.

Original WebRTC Server:
https://github.com/pchab/ProjectRTC

We implement code from AppRTC:
https://github.com/ISBX/apprtc-ios

